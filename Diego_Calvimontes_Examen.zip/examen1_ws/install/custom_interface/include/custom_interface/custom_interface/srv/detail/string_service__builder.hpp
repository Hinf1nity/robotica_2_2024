// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interface:srv/StringService.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACE__SRV__DETAIL__STRING_SERVICE__BUILDER_HPP_
#define CUSTOM_INTERFACE__SRV__DETAIL__STRING_SERVICE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interface/srv/detail/string_service__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interface
{

namespace srv
{

namespace builder
{

class Init_StringService_Request_a
{
public:
  Init_StringService_Request_a()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::custom_interface::srv::StringService_Request a(::custom_interface::srv::StringService_Request::_a_type arg)
  {
    msg_.a = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interface::srv::StringService_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interface::srv::StringService_Request>()
{
  return custom_interface::srv::builder::Init_StringService_Request_a();
}

}  // namespace custom_interface


namespace custom_interface
{

namespace srv
{

namespace builder
{

class Init_StringService_Response_response
{
public:
  Init_StringService_Response_response()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::custom_interface::srv::StringService_Response response(::custom_interface::srv::StringService_Response::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interface::srv::StringService_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interface::srv::StringService_Response>()
{
  return custom_interface::srv::builder::Init_StringService_Response_response();
}

}  // namespace custom_interface

#endif  // CUSTOM_INTERFACE__SRV__DETAIL__STRING_SERVICE__BUILDER_HPP_
